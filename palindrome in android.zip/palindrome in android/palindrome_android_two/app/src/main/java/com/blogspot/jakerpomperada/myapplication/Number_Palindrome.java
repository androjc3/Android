package com.blogspot.jakerpomperada.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.text.TextUtils;



public class Number_Palindrome extends AppCompatActivity {
 int given_number;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_number__palindrome);

    }

   public void clear_edit_text(View v) {
       final EditText value_given = (EditText) findViewById(R.id.editValueGiven);
       final TextView result = (TextView) findViewById(R.id.lblresult);
        result.setText("");
        value_given.setText("");
        value_given.requestFocus();
    }


    public void check_number(View v) {
       final EditText value_given = (EditText) findViewById(R.id.editValueGiven);
       final TextView result = (TextView) findViewById(R.id.lblresult);

      String GetEditText = value_given.getText().toString();

        if(TextUtils.isEmpty(GetEditText)){

            Toast.makeText(this, "Cannot Be Empty. Kindly provide a number.", Toast.LENGTH_SHORT).show();
            result.setText("");
            value_given.setText("");
            value_given.requestFocus();

        } else
        {
            try {
                given_number = Integer.parseInt(value_given.getText().toString());
            }catch (NumberFormatException e){
                Toast.makeText(this, "Not a number", Toast.LENGTH_SHORT).show();
            }

            int i = 0, reverse = 0;

            int q = given_number;

            for (i = 0; i <= given_number; i++) {
                reverse = reverse * 10;
                reverse = reverse + given_number % 10;
                given_number = given_number / 10;
                i = 0;
            }

            if (reverse == q) {
                result.setText(String.valueOf(q) + " is a Palindrome Number. ");
            } else {
                result.setText(String.valueOf(q) + " is not a Palindrome Number. ");
            }

        }


        }

    }
