package com.blogspot.jakerpomperada.myapplication;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


import java.util.*;


public class String_Palindrome extends AppCompatActivity {
 int given_number;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_string__palindrome);

    }

   public void clear_edit_text(View v) {
       final EditText value_given = (EditText) findViewById(R.id.editValueGiven);
       final TextView result = (TextView) findViewById(R.id.lblresult);
        result.setText("");
        value_given.setText("");
        value_given.requestFocus();
    }


    public void check_string(View v) {
       final EditText value_given = (EditText) findViewById(R.id.editValueGiven);
       final TextView result = (TextView) findViewById(R.id.lblresult);

      String GetEditText = value_given.getText().toString();

        if(TextUtils.isEmpty(GetEditText)){

            Toast.makeText(this, "Cannot Be Empty. Kindly provide a string or a word.", Toast.LENGTH_SHORT).show();
            result.setText("");
            value_given.setText("");
            value_given.requestFocus();

        } else
        {
            try {
                }catch (Exception  e){
                Toast.makeText(this, "Not a String", Toast.LENGTH_SHORT).show();
            }

            String  reverse = "";

            int length = GetEditText.trim().toLowerCase().length();

            for ( int i = length - 1; i >= 0; i-- )
                reverse = reverse + GetEditText.charAt(i);

            if (GetEditText.trim().toLowerCase().equals(reverse.trim().toLowerCase()))   {
                result.setText(GetEditText.toUpperCase() + " is a Palindrome String. ");
            } else {
                result.setText(GetEditText.toUpperCase() + " is not a Palindrome String. ");
            }

        }


        }

    }
