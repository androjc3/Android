package com.blogspot.jakerpomperada.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    public void string_palindrome(View v) {
        startActivity(new Intent(this, String_Palindrome.class));

    }
    public void number_palindrome(View v) {
        startActivity(new Intent(this, Number_Palindrome.class));

    }


    public void about_this_program(View v) {
        startActivity(new Intent(this, About.class));

   }
    public void quit(View v) {
        // Toast.makeText((getApplicationContext()), "This is my Toast message!",Toast.LENGTH_LONG).show();

        new AlertDialog.Builder(this)
                .setMessage("Quit This Program?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        MainActivity.this.finish();
                    }
                })
                .setNegativeButton("No", null)
                .show();
    }
}
